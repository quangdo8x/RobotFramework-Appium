from tkinter import Tk, END, N, WORD, W, StringVar, IntVar, Checkbutton, PhotoImage
from tkinter.scrolledtext import ScrolledText
from tkinter.filedialog import askopenfilename, asksaveasfilename
from tkinter.ttk import Label, Entry, Button, LabelFrame, Frame
from json import loads
import pandas as pd
from flatten_json import flatten

PROGRAM_NAME = "JSON To Excel Convertor"
SCROL_W = 50
SCROL_H = 15


class GUI():

    def __init__(self):
        # Create instance
        self.root = Tk()

        # Add a title
        self.root.title(PROGRAM_NAME)
        self.rq_body_scr = None
        self.rs_body_scr = None
        self.create_widgets()

    @classmethod
    def open_file(cls, content_text):
        input_file_name = askopenfilename(defaultextension="*.json",
                                          filetype=[("JSON", "*.json"), ("All Files", "*.*")])
        if input_file_name:
            content_text.delete(1.0, END)
            with open(input_file_name) as file:
                content_text.insert(1.0, file.read())

    def on_rq_open_button_clicked(self):
        self.open_file(self.rq_body_scr)

    def on_rs_open_button_clicked(self):
        self.open_file(self.rs_body_scr)

    def on_rq_copy_button_clicked(self):
        self.rq_body_scr.event_generate("<<Copy>>")
        return "break"

    def on_rs_copy_button_clicked(self):
        self.rs_body_scr.event_generate("<<Copy>>")
        return "break"

    def on_rq_paste_button_clicked(self):
        self.rq_body_scr.event_generate("<<Paste>>")
        return "break"

    def on_rs_paste_button_clicked(self):
        self.rs_body_scr.event_generate("<<Paste>>")
        return "break"

    def convert_to_df(self):
        request = {"request": loads(self.rq_body_scr.get(0.0, END))}
        response = {"response": loads(self.rs_body_scr.get(0.0, END))}
        data = {}
        data.update({'*** Test Cases ***': 'Define Test Case Name Here'})
        data.update({'[Tags]': 'Define Tags Here'})
        data.update({'[Documentation]': 'Define Documentation Here'})
        data.update(flatten({**request, **response}))
        for key, value in data.items():
            data[key] = [value]
        data_frame = pd.DataFrame(data)
        return data_frame

    @classmethod
    def write_to_file(cls, data_frame, file_name):
        writer = pd.ExcelWriter(file_name, engine='xlsxwriter') # pylint: disable=abstract-class-instantiated

        data_frame.to_excel(writer, sheet_name='Sheet 1', index=False, header=False, startrow=1)

        workbook = writer.book
        worksheet = writer.sheets['Sheet 1']

        header_format = workbook.add_format({
            'fg_color': '#5B9BD5',
            'font_color': 'white',
            'border' : 1
        })

        for col_num, value in enumerate(data_frame.columns.values):
            worksheet.write(0, col_num, value, header_format)

        writer.save()

    def on_convert_button_clicked(self):
        output_file_name = asksaveasfilename(defaultextension=".xlsx",
                                             filetypes=[("Excel Files", "*.xlsx")])
        if output_file_name:
            data_frame = self.convert_to_df()
            self.write_to_file(data_frame, output_file_name)

    @classmethod
    def create_open_file_button(cls, parent, command):
        open_file_icon = PhotoImage(file='icons/open_file.gif')
        rq_file_btn = Button(parent, command=command, image=open_file_icon)
        rq_file_btn.image = open_file_icon
        rq_file_btn.grid(column=0, row=0, padx=5, pady=5, sticky=N + W)

#    @classmethod
#    def create_paste_button(cls, parent, command):
#        paste_icon = PhotoImage(file='icons/paste.gif')
#        rq_paste_btn = Button(parent, command=command, image=paste_icon)
#        rq_paste_btn.image = paste_icon
#        rq_paste_btn.grid(column=1, row=0, padx=5, pady=5, sticky=N + W)

#    @classmethod
#    def create_copy_button(cls, parent, command):
#        copy_icon = PhotoImage(file='icons/copy.gif')
#        rq_copy_btn = Button(parent, command=command, image=copy_icon)
#        rq_copy_btn.image = copy_icon
#        rq_copy_btn.grid(column=2, row=0, padx=5, pady=5, sticky=N + W)

    @classmethod
    def create_content_text(cls, parent):
        body_scr = ScrolledText(parent, width=SCROL_W, height=SCROL_H, wrap=WORD)
        body_scr.grid(column=0, row=1, padx=5, pady=5, rowspan=3)
        return body_scr

    def create_json_frame(self, parent):
        json_frame = LabelFrame(parent, text=" JSON ", borderwidth=5, width=200, height=100)
        json_frame.grid(column=0, row=0, sticky=N, padx=5, pady=5)
        self.create_request_frame(json_frame)
        self.create_response_frame(json_frame)

    def create_request_frame(self, parent):
        rq_frame = LabelFrame(parent, text=" Request Body ")
        rq_frame.grid(column=0, row=0, padx=5, pady=5)

        rq_btn_frame = Frame(rq_frame)
        rq_btn_frame.grid(column=0, row=0)

        self.create_open_file_button(rq_btn_frame, self.on_rq_open_button_clicked)
#        self.create_paste_button(rq_btn_frame, self.on_rq_paste_button_clicked)
#        self.create_copy_button(rq_btn_frame, self.on_rq_copy_button_clicked)

        self.rq_body_scr = self.create_content_text(rq_frame)

    def create_response_frame(self, parent):
        # Response Frame
        rs_frame = LabelFrame(parent, text=" Response Body ")
        rs_frame.grid(column=1, row=0, padx=5, pady=5)

        rs_btn_frame = Frame(rs_frame)
        rs_btn_frame.grid(column=0, row=0)

        self.create_open_file_button(rs_btn_frame, self.on_rs_open_button_clicked)
#        self.create_copy_button(rs_btn_frame, self.on_rs_copy_button_clicked)
#        self.create_paste_button(rs_btn_frame, self.on_rs_paste_button_clicked)

        self.rs_body_scr = self.create_content_text(rs_frame)

    @classmethod
#    def create_excel_frame(cls, parent):
#        # Excel Frame
#       excel_frame = LabelFrame(parent, text=" Excel ", borderwidth=5, width=200, height=100)
#        excel_frame.grid(column=0, row=1, sticky=N + W)
#
#        sheet_name_lbl = Label(excel_frame, text="Sheet Name")
#        sheet_name_lbl.grid(column=0, row=0)
#
#        sheet_name = StringVar()
#        sheet_name_entry = Entry(excel_frame, text="Sheet 1", textvariable=sheet_name)
#        sheet_name_entry.grid(column=1, row=0, sticky=W)

#        check_test_cases_cln_var = IntVar()
#        check_test_cases_cln = Checkbutton(excel_frame, text="*** Test Cases ***",
#                                           variable=check_test_cases_cln_var)
#        check_test_cases_cln.grid(column=0, row=1, sticky=W)

#        check_tags_var = IntVar()
#        check_tags = Checkbutton(excel_frame, text="[Tags]", variable=check_tags_var)
#        check_tags.grid(column=0, row=2, sticky=W)

#        check_documentation_var = IntVar()
#        check_documentation = Checkbutton(excel_frame, text="[Documentation]",
#                                          variable=check_documentation_var)
#        check_documentation.grid(column=0, row=3, sticky=W)

    def create_convert_button(self, parent):
        action = Button(parent, text="Convert", command=self.on_convert_button_clicked)
        action.grid(column=0, row=1, pady=10)

    def create_widgets(self):
        self.create_json_frame(self.root)
#        self.create_excel_frame(self.root)
        self.create_convert_button(self.root)

# Start GUI
app = GUI()
app.root.mainloop()
