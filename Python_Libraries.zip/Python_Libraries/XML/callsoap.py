import requests

def Call_Soap(url, body):
    url = url
    body = body
    headers = {
        'Content-Type': "text/xml",
    }
    response = requests.request("POST", url, verify=False, data=body, headers=headers)
    return response
