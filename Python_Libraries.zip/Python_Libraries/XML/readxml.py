import	xmltodict

def Read_Xml_File(file_path):
    with open(file_path, encoding='utf-8') as fd:
        obj = fd.read()
    return obj

def Convert_Xml_File_To_dict(file_path):
    with open(file_path, encoding='utf-8') as fd:
        obj = xmltodict.parse(fd.read(), dict_constructor=dict, xml_attribs=False)
    return obj

def Convert_Xml_To_Dict(xml):
    obj = xmltodict.parse(xml, dict_constructor=dict, xml_attribs=False)
    return obj