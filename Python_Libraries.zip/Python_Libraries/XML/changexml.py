from lxml import etree as ET

def Update_Template(path1, path2):
    et=ET.parse(path1)
    et.write(path2)
    
def Update_Field_Data(file_path, elementName, elementValue):
    # Parse data from file xml
    et = ET.parse(file_path)
    # Find Element need to update
    ele = et.find(".//" + elementName)
    # Update data of element
    ele.text = elementValue
    # Save data
    et.write(file_path)

def Get_Value(file_path, elementName):
    # Parse data from file xml
    et = ET.parse(file_path)
    # Find element
    ele = et.find(".//" + elementName)
    # Return data
    return ele.text


def Update_Data(file_path, elementName, dataExcel, start, end, plus):
    print(dataExcel)
    et = ET.parse(file_path)
    el = et.find(".//" + elementName)
    start = int(start)
    end = int(end)
    plus = int(plus)
    for i in range(start, end):
        el[i].text = dataExcel[i + plus]
    et.write(file_path)


def Update_Data_Error(file_path, elementName, dataExcel):
    et = ET.parse(file_path)
    el = et.find(".//" + elementName)
    for child in el:
        child.text = dataExcel[el.index(child) + 1]
    et.write(file_path)


def Update_Data_Occurrence(file_path, elementName, dataExcel):
    et = ET.parse(file_path)
    el = et.find(".//" + elementName)
    for child in el:
        child.text = dataExcel[el.index(child) + 1]
    et.write(file_path)


def Update_List_Data(file_path, elementName, obj, dataExcel):
    print(dataExcel)
    et = ET.parse(file_path)
    el = list(et.iter(elementName))
    for child in el[obj]:
        print(el[obj].index(child))
        print(dataExcel[el[obj].index(child)+1])
        child.text = dataExcel[el[obj].index(child)+1]
    et.write(file_path)

def Update_Data_Test(file_path, header, data):
    et = ET.parse(file_path)
    for child in header:
        print(child)
        el = et.find(".//" + child)
        el.text = data[header.index(child)]        
    et.write(file_path)

def Update_Data_Test_Occurrence(file_path, header, data, occurrence):
    et = ET.parse(file_path)
    for child in header:
        if child != occurrence:
            print(child)
            el = et.find(".//" + child)
            el.text = data[header.index(child)]
    et.write(file_path)

def Remove_Element(file_path, root, element):
    et = ET.parse(file_path)
    el = et.find(".//" + root)
    el_remove = et.find(".//" + element)
    el.remove(el_remove)
    et.write(file_path, pretty_print=True)

def Insert_Element(file_path, root, index, element):
    et = ET.parse(file_path)
    el = et.find(".//" + root)
    el_insert = ET.Element(element)
    el.insert(index, el_insert)
    et.write(file_path, pretty_print=True)