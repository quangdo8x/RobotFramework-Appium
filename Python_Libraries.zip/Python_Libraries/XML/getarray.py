def Get_List(ls, t):
    a=[]
    for i in ls:
        j=str(i)
        if t in j:
            a.append(j)
    return a
    
def Convert(string): 
    li = list(string.split(","))
    for i in range(0, len(li)):
        li[i].strip(' ')
        li[i] = int(li[i]) 
    return li
    
def Check_Contain(string):
    if '+' in string:
        return '+'
    else:
        return '-'