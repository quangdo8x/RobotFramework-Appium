import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def define_nossl():
	pass