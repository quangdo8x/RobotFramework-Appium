from DataDriver.AbstractReaderClass import AbstractReaderClass
from DataDriver.ReaderConfig import ReaderConfig
from DataDriver.ReaderConfig import TestCaseData
import re
from .flatten_json import unflatten_list
import json


class ExtendedAbstractReaderClass(AbstractReaderClass):

    def __init__(self, reader_config: ReaderConfig):

        self.file = reader_config.file
        self.csv_encoding = reader_config.encoding
        self.csv_dialect = reader_config.dialect
        self.delimiter = reader_config.delimiter
        self.quotechar = reader_config.quotechar
        self.escapechar = reader_config.escapechar
        self.doublequote = reader_config.doublequote
        self.skipinitialspace = reader_config.skipinitialspace
        self.lineterminator = reader_config.lineterminator
        self.sheet_name = reader_config.sheet_name
        self.kwargs = reader_config.kwargs

        self.test_case_column_id = None
        self.request_column_ids = []
        self.response_column_ids = []
        self.arguments_column_ids = []
        self.tags_column_id = None
        self.documentation_column_id = None
        self.header = []
        self.data_table = []
        self.ignores = []

        self.TESTCASE_TABLE_NAME = ReaderConfig.TEST_CASE_TABLE_NAME
        self.TEST_CASE_TABLE_PATTERN = r'(?i)^(\*+\s*test ?cases?[\s*].*)'
        self.TASK_TABLE_PATTERN = r'(?i)^(\*+\s*tasks?[\s*].*)'
        self.VARIABLE_PATTERN = r'([$@&]{1}\{)(.*?)(\})'
        self.TAGS_PATTERN = r'(?i)(\[)(tags)(\])'
        self.DOCUMENTATION_PATTERN = r'(?i)(\[)(documentation)(\])'
        self.REQUEST_PATTERN = r'(^request_.*?)'
        self.RESPONSE_PATTERN = r'(^response_.*?)'
        self.IGNORE_TAG = '[IGNORES]'

    def _analyse_header(self, header_cells):
        self.header = header_cells
        for cell_index, cell in enumerate(self.header):
            if self._is_test_case_header(cell):
                self.test_case_column_id = cell_index
            if self._is_request(cell):
                self.request_column_ids.append(cell_index)
            elif self._is_response(cell):
                self.response_column_ids.append(cell_index)
            elif self._is_variable(cell):
                self.arguments_column_ids.append(cell_index)
            elif self._is_tags(cell):
                self.tags_column_id = cell_index
            elif self._is_documentation(cell):
                self.documentation_column_id = cell_index
                
    def _is_request(self, header_string: str):
        if re.match(self.REQUEST_PATTERN, header_string):
            return True

    def _is_response(self, header_string: str):
        if re.match(self.RESPONSE_PATTERN, header_string):
            return True
            
    def format_string(self, string):
        cell_value = string.lower()
        if 'number(' in cell_value or 'num(' in cell_value:
            string = string.split('(')[1]
            string = int(float(string.split(')')[0]))
        elif 'decimal(' in cell_value or 'dec(' in cell_value:
            string = string.split('(')[1]
            string = float(string.split(')')[0])
        return string

    def _read_data_from_table(self, row):
            test_case_name = row[self.test_case_column_id] if self.test_case_column_id is not None else ''
            arguments = {}
            for arguments_column_id in self.arguments_column_ids:
                arguments[self.header[arguments_column_id]] = row[arguments_column_id]
            tags = [t.strip() for t in row[self.tags_column_id].split(',')] if self.tags_column_id else None
            documentation = row[self.documentation_column_id] if self.documentation_column_id else ''
            
            # Create variable ${request}
            request = {}
            for request_column_id in self.request_column_ids:
                cell_value = self.format_string(row[request_column_id])
                request[self.header[request_column_id]] = cell_value
            unflatten_request = unflatten_list(request)
            arguments["${request}"] = unflatten_request["request"]
            
            # Create variable ${response}
            response = {}
            for response_column_id in self.response_column_ids:
                cell_value = self.format_string(row[response_column_id])
                response[self.header[response_column_id]] = cell_value
            unflatten_response = unflatten_list(response)
            arguments["${response}"] = unflatten_response["response"]
            
            # Create variable ${ignores}
            ignores = []
            for response_column_id in self.response_column_ids:
                if row[response_column_id] == self.IGNORE_TAG:
                    ignores.append(self.header[response_column_id].replace("response_", "").replace("_", "."))
            arguments["${ignores}"] = ignores
            
            self.data_table.append(TestCaseData(test_case_name, arguments, tags, documentation))
