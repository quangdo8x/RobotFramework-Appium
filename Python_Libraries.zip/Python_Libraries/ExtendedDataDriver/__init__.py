import importlib
import os.path
import re

from DataDriver import DataDriver
from .ExtendedAbstractReaderClass import ExtendedAbstractReaderClass
from DataDriver.ReaderConfig import ReaderConfig
from DataDriver.ReaderConfig import TestCaseData


class ExtendedDataDriver(DataDriver):
        
    def _get_data_reader_from_file_extension(self):
        file_extension = os.path.splitext(self.reader_config.file)[1]
        reader_type = file_extension.lower()[1:]
        self._debug(f'[ DataDriver ] Initialized in {reader_type}-mode.')
        if reader_type == "xlsx":
            reader_type = "extended_xlsx"
            reader_module = importlib.import_module(f'..{reader_type}_reader', 'ExtendedDataDriver.ExtendedDataDriver')
        else:
            reader_module = importlib.import_module(f'..{reader_type}_reader', 'DataDriver.DataDriver')
        self._debug(f'[ DataDriver ] Reader Module: {reader_module}')
        reader_class = getattr(reader_module, f'{reader_type}_reader')
        return reader_class
