from REST import REST
from .extendedkeywords import ExtendedKeywords


class ExtendedRESTLibrary(REST, ExtendedKeywords):
    """
    This is extended from RESTinstance library for REST API testing.
    """

    def __init__(self, timeout=10):
        """
        Default value for timeouts used with GET, POST, PATCH, PUT, DELETE, OPTIONS, HEAD keywords.
        """
        super(ExtendedRESTLibrary, self).__init__(ssl_verify=False)
        self.timeout = timeout
