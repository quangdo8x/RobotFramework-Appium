import os
from typing import Dict, Any
from JSONLibrary import JSONLibrary
from robot.api import logger
from importlib.machinery import SourceFileLoader
from robot.api.deco import keyword
from .TagGenerate import TagGenerate


class DataSolution:
    __EXCEL_IMPORT = SourceFileLoader(
        'ExcelImportLibrary',
        os.getcwd() + '/libs/ExcelImportLibrary/__init__.py'
    ).load_module().ExcelImportLibrary()
    __TAG_GENERATE = TagGenerate()
    __JSON_HELPER = JSONLibrary()
    __FETCH_DATA = {
        'req': {
            'headers': {},
            'body': {}
        },
        'res': {
            'headers': {},
            'body': {}
        }
    }

    def __init__(self):
        self.test_data_path = None
        self.fetch_position = None
        self.keyname_start_body = None
        self.__flag = None

    @keyword("Select Test Data File")
    def select_testdata_file(self, path: str):
        self.test_data_path = path
        self.__EXCEL_IMPORT.open_excel_file(self.test_data_path)
        self.__FETCH_DATA = {
            'req': {
                'headers': {},
                'body': {}
            },
            'res': {
                'headers': {},
                'body': {}
            }
        }

    def __get_key_start_body(self, data):
        max_column = self.__EXCEL_IMPORT.get_max_column()
        found_body = False
        position = 0
        for i in range(max_column):
            group_name = str(self.__EXCEL_IMPORT.get_cell(1, i + 1)).lower()
            if group_name == 'body':
                self.keyname_start_body = self.__EXCEL_IMPORT.get_cell(2, i + 1)
                return self.keyname_start_body

    @keyword("Load Test Data")
    def load_test_data(self, sheet_name: str, search: str,
                        var_name_row=2, search_col=1, join_name=None):
        self.__EXCEL_IMPORT.select_excel_sheet(sheet_name)
        raw_data = self.__EXCEL_IMPORT.find_test_case(sheet_name, search, var_name_row, search_col)
        raw_data = raw_data[0]['values']
        raw_data.pop(None, None)
        if join_name is None:
            self.__get_key_start_body(raw_data)
            self.fetch_position = sheet_name
            self.__flag = False
        index = 1
        for key in raw_data:
            value: object = raw_data[key]
            value = value[0]
            logger.debug(self.keyname_start_body)
            if self.keyname_start_body == key or self.__flag:
                self.__flag = True
            new_key = f"{join_name}.{key}" if join_name is not None else f"{key}"
            if new_key[-1] != '*':  # normal data
                if sheet_name != self.fetch_position and index == 1:  # not use first column data
                    pass
                else:
                    if self.__flag:
                        self.__FETCH_DATA[self.fetch_position]['body'][new_key] = value
                    else:
                        self.__FETCH_DATA[self.fetch_position]['headers'][new_key] = value
            elif value is None: # link data with empty string
                if self.keyname_start_body == new_key or self.__flag:
                    self.__FETCH_DATA[self.fetch_position]['body'][new_key] = value
                else:
                    self.__FETCH_DATA[self.fetch_position]['headers'][new_key] = value
            else: # link data (*) set others value
                if value == '[REMOVE]':
                    new_key = new_key.replace('*', '')
                    if self.keyname_start_body == new_key or self.__flag:
                        self.__FETCH_DATA[self.fetch_position]['body'][new_key] = value
                    else:
                        self.__FETCH_DATA[self.fetch_position]['headers'][new_key] = value
                    index = index + 1
                    continue
                elif value == '[IGNORE]':
                    index = index + 1
                    continue
                elif str(value).lower() == 'null':
                    if self.keyname_start_body == new_key or self.__flag:
                        self.__FETCH_DATA[self.fetch_position]['body'][new_key] = value
                    else:
                        self.__FETCH_DATA[self.fetch_position]['headers'][new_key] = value
                    index = index + 1
                    continue
                elif value == '{}':
                    if self.keyname_start_body == new_key or self.__flag:
                        self.__FETCH_DATA[self.fetch_position]['body'][new_key] = value
                    else:
                        self.__FETCH_DATA[self.fetch_position]['headers'][new_key] = value
                    index = index + 1
                    continue
                # link data (*) set link value
                sheet_name = key[0:-1]
                found = str(value).find('[')
                is_list = False
                if found > -1:
                    is_list = True
                    value = str(value).replace("[", "").replace("]", "")
                value = str(value).split(",")
                sub_index = 0
                for link_value in value:
                    link_value = link_value.strip()
                    new_name = new_key.replace("*", "")
                    new_name = f"{new_name}[{sub_index}]" if is_list else new_name
                    self.load_test_data(sheet_name, link_value,
                                         var_name_row=1, search_col=1, join_name=new_name)
                    sub_index = sub_index + 1
            index = index + 1

    @keyword("Update Data With Test Data")
    def update_data_with_test_data(self, json_data: dict, group: str, part: str = 'body'):
        keys = self.__FETCH_DATA[group][part].keys()
        for key in keys:
            value = self.__FETCH_DATA[group][part][key]
            json_data = self.__update_all_value_type(json_data, key, value)
        return json_data

    def __update_all_value_type(self, json_data, key, value, pass_ignore: bool = True):
        key = str(key).replace('(RQ)', '').replace('*', '')
        if type(value) is type(None):
            json_data = self.__JSON_HELPER.update_value_to_json(json_data, '$..' + key, '')
        elif type(value) is float or type(value) is int:
            json_data = self.__JSON_HELPER.update_value_to_json(json_data, '$..' + key, value)
        elif type(value) is str:
            if value == '[REMOVE]': # >>> [REMOVE] : remove key and value from template body
                json_data = self.__JSON_HELPER.delete_object_from_json(json_data, '$..' + key)
            elif value == '[IGNORE]': # >>> [IGNORE] : use default value in template body
                if pass_ignore:
                    pass
                else:
                    json_data = self.__JSON_HELPER.update_value_to_json(json_data, '$..' + key, '')
            elif str(value).find('[') > -1 and str(value).find(']') > -1: # [SPECIAL_TAG] : tag need to generate new value
                try:
                    json_data = self.__JSON_HELPER.update_value_to_json(
                        json_data, '$..' + key, self.__TAG_GENERATE.generate_value_for_tag(value)
                    )
                except Exception:
                    logger.error(f'Please check test data. may be data was set with wrong tag : {value}')
                    raise
            elif value == 'null': # 'null need to set value to null (json) or None (dict)
                json_data = self.__JSON_HELPER.update_value_to_json(json_data, '$..' + key, None)
            elif value == '{}': # '{} need to set empty dict
                json_data = self.__JSON_HELPER.update_value_to_json(json_data, '$..' + key, {})
            else: # >>> normal value str, number : just update
                json_data = self.__JSON_HELPER.update_value_to_json(json_data, '$..' + key, value)
        return json_data

    @keyword("Verify Data")
    def verify_data_with_test_data(self, actual_data, group: str = 'res', part: str = 'body'):
        expected_data = self.__FETCH_DATA[group][part]
        expected_keys = expected_data.keys()
        self.__flag = True
        for key in expected_keys:
            expected_value = expected_data[key]
            new_key = str(key).replace('(RS)', '').replace('*', '')
            actual_value = self.__JSON_HELPER.get_value_from_json(actual_data, '$..' + new_key)
            key_result = self.__verify_value_by_value(key, actual_value, expected_value)
            if not key_result:
                if len(actual_value) >= 1:
                    actual_value = actual_value[0]
                else:
                    actual_value = 'NOT FOUND'
                logger.error(f"\"{key}\" is {actual_value} , it should be {expected_value}")
                self.__flag = False
        return self.__flag

    def __verify_value_by_value(self, expected_key, actual_value, expected_value):
        if type(expected_value) is type(None): # empty string
            expected_value = ''
            if len(actual_value) >= 1:
                if expected_value == actual_value[0]:
                    return True
                elif type(actual_value[0]) is dict:
                    return True
            return False
        elif type(expected_value) is float or type(expected_value) is int: # numbers
            if len(actual_value) >= 1:
                if expected_value == actual_value[0]:
                    return True
            return False
        elif type(expected_value) is str: # string
            if expected_value == '[REMOVE]': # [REMOVE] tag
                if len(actual_value) == 0:
                    return True
                return False
            elif expected_value == '[IGNORE]': # [IGNORE] tag
                if len(actual_value) >= 1:
                    return True
                return False
            elif str(expected_value).find('[') > -1 and str(expected_value).find(']') > -1: # [SPECIAL_TAG] : tag need to generate new value
                expected_value = self.__TAG_GENERATE.generate_value_for_tag(expected_value)
                if len(actual_value) >= 1:
                    if expected_value == actual_value[0]:
                        return True
                return False
            elif expected_value == 'null': # 'null need to set value to null (json) or None (dict)
                expected_value = None
                if len(actual_value) >= 1:
                    if expected_value == actual_value[0]:
                        return True
                return False
            elif expected_value == '{}': # '{} empty dict
                if len(actual_value) >= 1 and type(actual_value[0]) is dict:
                    return True
                return False
            elif str(expected_value).find('<or>') > -1: # <or> condition in string
                expected_value = str(expected_value).split('<or>')
                for value in expected_value:
                    value = str(value).strip()
                    if len(actual_value) >= 1:
                        new_value = str(actual_value[0])
                        if value == new_value:
                            return True
                return False
            else: # normal string
                if len(actual_value) >= 1:
                    if expected_value == actual_value[0]:
                        return True
                return False
        return False

    @keyword("Get Headers")
    def get_headers(self, group: str, part: str = 'headers'):
        new_headers = self.__FETCH_DATA[group][part].copy()
        keys = self.__FETCH_DATA[group][part].keys()
        for key in keys:
            value = self.__FETCH_DATA[group][part][key]
            new_headers = self.__update_all_value_type(new_headers, key, value, pass_ignore=False)
        return new_headers

    @keyword("Get Test Data")
    def get_test_data(self):
        return self.__FETCH_DATA
