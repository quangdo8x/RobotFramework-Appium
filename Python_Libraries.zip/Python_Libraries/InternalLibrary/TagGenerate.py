from robot.api.deco import keyword
from datetime import datetime, timezone
from datetime import timedelta
from tzlocal import get_localzone
import re
import uuid
from robot.api import logger

class TagGenerate():
    __existed = {
        'ROBOT': None,
        'ISO_DT': None,
        'UTC_DT': None,
        'UTC_DATE': None
    }

    def __init__(self):
        pass

    @keyword("Verify Tag By Regular Expression")
    def verify_tag_by_regular_expression(self, expected, actual, conj="??????"):
        expected = str(expected).replace("[", "\[").replace("]", "\]").replace("(", "\(").replace(")", "\)").replace(
            ".", "\.")
        expected = str(expected).split(conj)
        size = len(expected)
        ex_reg = ''
        for i in range(size):
            if i == 0:
                ex_reg = '^' + ex_reg + expected[i] + '.*'
            elif i == size - 1:
                ex_reg = ex_reg + expected[i]
            else:
                ex_reg = ex_reg + expected[i] + '.*'
        result = re.search(ex_reg, actual)
        if result:
            return True
        else:
            return False

    @keyword("Generate Value For Tag")
    def generate_value_for_tag(self, tag):
        if self.verify_tag_by_regular_expression('[AUTO_GEN_DOC_ID]', tag):
            size = 13
            return self.__auto_gen_id(tag, size)
        elif self.verify_tag_by_regular_expression('[AUTO_GEN_??????_ID]', tag, '_??????_'):
            return self.__auto_gen_id(tag)
        elif self.verify_tag_by_regular_expression('[EXIST_??????_ID]', tag, '_??????_'):
            return self.__exist_id(tag)
        elif self.verify_tag_by_regular_expression('[NOW_ISO_DT]', tag):
            return self.__now_iso_datetime()
        elif self.verify_tag_by_regular_expression('[NOW_UTC_DT]', tag):
            return self.__now_utc_datetime()
        elif self.verify_tag_by_regular_expression('[NOW_UTC_DATE]{+/-}{days}D', tag, '{+/-}{days}D'):
            return self.__now_utc_date(tag)
        elif self.verify_tag_by_regular_expression('[EXIST_UTC_DT]', tag):
            return self.__exist_utc_datetime()
        elif self.verify_tag_by_regular_expression('[EXIST_ISO_DT]', tag):
            return self.__exist_iso_datetime()
        elif self.verify_tag_by_regular_expression('[EXIST_UTC_DATE]', tag):
            return self.__exist_utc_date()
        elif self.verify_tag_by_regular_expression('[NOW_UID]', tag):
            return self.__now_uid()
        elif self.verify_tag_by_regular_expression('[NOW_DATE]', tag):
            return self.__now_date_with_local_timezone()
        return tag

    def __auto_gen_id(self, tag, size: int = -1):
        id_name = str(tag).split('_')
        id_name = id_name[2] if id_name[2] != 'ID]' else 'ROBOT'
        now = datetime.now()
        now = now.strftime("%Y%m%d_%H%M%S%f")
        now = str(now)[0:19]
        value = id_name + '_' + now
        if size != -1:
            start = len(value) - size
            value = value[start:len(value)]
        self.__existed[id_name] = str(value)
        return value

    def __exist_id(self, tag):
        id_name = str(tag).split('_')
        id_name = id_name[1] if id_name[1] != 'ID]' else 'ROBOT'
        value = self.__existed[id_name]
        return value

    def __now_iso_datetime(self):
        value = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
        self.__existed['ISO_DT'] = str(value)
        return value

    def __exist_iso_datetime(self):
        return self.__existed['ISO_DT']

    def __now_utc_datetime(self):
        utc_dt = datetime.now(timezone.utc)
        utc_dt = format(utc_dt.astimezone(get_localzone()).isoformat())
        value = str(utc_dt)[0:23] + str(utc_dt)[26:32]
        self.__existed['UTC_DT'] = str(value)
        return value

    def __exist_utc_datetime(self):
        return self.__existed['UTC_DT']

    def __now_utc_date(self, tag):
        value = None
        if str(tag).find('+') == -1 and str(tag).find('-') == -1:
            value = datetime.now()
        elif str(tag).find('+') > -1:
            value = str(tag).split("+")
            num_day = int(value[1][0:-1])
            value = datetime.now() + timedelta(days=num_day)
        elif str(tag).find('-') > -1:
            value = str(tag).split("-")
            num_day = int(value[1][0:-1])
            value = datetime.now() - timedelta(days=num_day)
        value = value.strftime("%Y-%m-%d")
        self.__existed['UTC_DATE'] = str(value)
        return value

    def __exist_utc_date(self):
        return self.__existed['UTC_DATE']

    def __now_uid(selt):
        value = uuid.uuid1()
        return str(value)

    def __now_date_with_local_timezone(self):
        """Get current date with local timezone."""
        try:
            utc_dt = datetime.now(timezone.utc)
            # Use tzlocal get_localzone
            import pytz
            utc_dt = format(utc_dt.astimezone(pytz.timezone('Asia/Bangkok')).isoformat())
            return utc_dt
        except Exception as e:
            logger.error('Get Current Date With Local Timezone method: ' + str(e))