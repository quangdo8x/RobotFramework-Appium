from .DataSolution import DataSolution
from .TagGenerate import TagGenerate

__version__ = '1.0.0'


class InternalLibrary(TagGenerate, DataSolution):

    '''
        InternalLibrary for create custom function or some solution to help automate test project.
        Used in seperate project

        last update: 14-Feb-2019
    '''

    ROBOT_LIBRARY_VERSION = __version__
    
    
    def __init__(self):
        DataSolution.__init__(self)
