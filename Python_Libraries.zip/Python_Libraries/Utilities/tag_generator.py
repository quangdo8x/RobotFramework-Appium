from robot.api import logger
from robot.api.deco import keyword
import re
import copy


def _is_remove(value) -> bool:
    if re.match(r'\[REMOVE\]', value):
        return True
    else:
        return False

def _is_null(value) -> bool:
    if re.match(r'\[NULL\]', value):
        return True
    else:
        return False

def recursive_update_dictionary_by_tags(my_dict, parent_dict=None, parent_key=None):
    if isinstance(my_dict, dict):
        for key, value in list(my_dict.items()):
            if isinstance(value, dict):
                recursive_update_dictionary_by_tags(value, my_dict, key)
            elif isinstance(value, list):
                found = 0
                for i in range(len(value)):
                    clear_dict = recursive_update_dictionary_by_tags(value[i - found], value, i - found)
                    if clear_dict:
                        found = found + 1
                if len(value) == 0:
                    remove_key_in_dictionary(value, my_dict, key)
            else:
                value = str(value)
                if _is_remove(value):
                    del my_dict[key]
                elif _is_null(value):
                    my_dict[key] = ''
            removed = remove_key_in_dictionary(my_dict, parent_dict, parent_key)
    return removed

def remove_key_in_dictionary(my_dict, parent_dict=None, parent_key=None):
    if _is_empty_dict(my_dict):
        if parent_dict is not None:
            del parent_dict[parent_key]
            return True
    return False

@keyword
def update_dictionary_by_tags(my_dict):
    """
    Update dictionary by tags.
    """
    new_dict = copy.deepcopy(my_dict)
    recursive_update_dictionary_by_tags(new_dict)
    return new_dict

def _is_empty_dict(my_dict) -> bool:
    found = True
    if isinstance(my_dict, dict):
        for key in list(my_dict.keys()):
            if key:
	            found = False
    if isinstance(my_dict, list):
        for i in range(len(my_dict)):
	        if not _is_empty_dict(my_dict[i]):
	            found = False
	            break
    return found
