from .dict_management import *
from .utilities import *
from .dt_management import *
from .xml_management import *
from .socket_management import *
from .tag_generator import update_dictionary_by_tags
