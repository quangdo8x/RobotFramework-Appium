from robot.api import logger
from datetime import datetime, timezone, time
import time
from .utilities import *
from robot.api.deco import keyword


@keyword("Get Now UTC Datetime")
def get_now_datetime() -> str:
    """
    Customize datetime format (Updated from get_current_date_with_local_timezone function).

    Example now datetime:

    2019-11-06T00:00:00.000+07:00

    Return type: string
    """
    try:
        th_now = get_current_date_with_local_timezone()
        th_now = str(th_now)
        return str(th_now)[0:23] + str(th_now)[26:32]
    except Exception as info:
        logger.error(f"{__name__} Can not get now datetime : {info}")
        raise

@keyword("Get Now ISO Datetime")
def get_now_datetime_iso() -> str:
    """
    Get datetime ISO format.

    Example now datetime:

    2019-01-19T23:20:25.459Z
    Return type: string
    """
    try:
        now_dt = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
        return now_dt
    except Exception as info:
        logger.error(f"{__name__} Can not get now datetime iso : {info}")
        raise

@keyword("Get Now Total Seconds")
def get_now_total_seconds() -> int:
    """
    Customize datetime format to total seconds form.

    Example now total seconds:

    1574628877

    Return type: string
    """
    try:
        total_sec = datetime.utcnow()
        total_sec = time.mktime(total_sec.timetuple())
        total_sec = int(total_sec)
        return total_sec
    except Exception as info:
        logger.error(f"{__name__} Can not get now total seconds : {info}")
        raise
