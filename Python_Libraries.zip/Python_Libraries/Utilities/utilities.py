from json import loads
from dictdiffer import diff
from tzlocal import get_localzone
from datetime import datetime, timezone, time
from robot.api import logger
import time
import pytz
from sys import platform
import re
import os
from os.path import isfile, join
import requests
from robot.api.deco import keyword


def load_json_from_file(file_path):
    """Loads and returns json from a given file."""
    return loads(open(file_path, encoding='utf-8').read())

def get_current_date_with_local_timezone():
    """Get current date with local timezone."""
    try:
        utc_dt = datetime.now(timezone.utc)
        # Use tzlocal get_localzone
        utc_dt = format(utc_dt.astimezone(pytz.timezone('Asia/Bangkok')).isoformat())
        return utc_dt
    except Exception as e:
        logger.error('Get Current Date With Local Timezone method: ' + str(e))

def print_friendly_message(result):
    """
    Customize returning message after comparing the value between two dictionaries.

    Result: The result after comparing two dictionaries.
    """
    try:
        message = ""
        for arr in result:
            msg = ""
            if str(arr[0]) == 'change':
                elements = ""
                flags = False
                if isinstance(arr[1], str):
                    msg = "The value of \"{}\" is changed from \"{}\" to \"{}\"\n".format(str(arr[1]), str(arr[2][0]),
                                                                                          str(arr[2][1]))
                elif isinstance(arr[1], list):
                    narr = arr[1]
                    for i in range(len(narr)):
                        elements += narr[i] + "."
                        if isinstance(narr[i], int):
                            flags = True
                            list1 = narr[0:i]
                            for j in range(len(list1)):
                                nlist1 = ".".join(list1)
                            list2 = narr[i + 1:]
                            for k in range(len(list2)):
                                nlist2 = ".".join(list2)
                            msg = "The value of \"{}\" at index \"{}\" of \"{}\" is changed from \"{}\" to \"{}\"\n".format(
                                nlist2, narr[i], nlist1, str(arr[2][0]), str(arr[2][1]))
                            break
                    if flags == False:
                        elements = elements[:-1]
                        msg = "The value of \"{}\" is changed from \"{}\" to \"{}\"\n".format(elements, str(arr[2][0]),
                                                                                              str(arr[2][1]))
            elif str(arr[0]) == "remove":
                if str(arr[1]) == "":
                    msg = "The attribute \"{}\" is removed into actual result\n".format(str(arr[2][0][0]))
                elif isinstance(arr[1], list):
                    msg = "The attribute \"{}\" at index \"{}\" of \"{}.{}\" is removed into actual result\n".format(
                        str(arr[2][0][0]), str(arr[1][2]), str(arr[1][0]), str(arr[1][1]))
                else:
                    msg = "The attribute \"{}.{}\" is removed into actual result\n".format(str(arr[1]),
                                                                                           str(arr[2][0][0]))
            elif str(arr[0]) == "add":
                if str(arr[1]) == "":
                    msg = "The attribute \"{}\" is added into actual result\n".format(str(arr[2][0][0]))
                elif isinstance(arr[1], list):
                    msg = "The attribute \"{}\" at index \"{}\" of \"{}.{}\" is added into actual result\n".format(
                        str(arr[2][0][0]), str(arr[1][2]), str(arr[1][0]), str(arr[1][1]))
                else:
                    msg = "The attribute \"{}.{}\" is added into actual result\n".format(str(arr[1]), str(arr[2][0][0]))
            message += msg
        message = message[:-1]
        return message
    except Exception as e:
        logger.error('Print Message Value method: ' + str(e))

def check_type(actual, expect):
    try:
        diffs = list(diff(expect, actual))
        diffs = list(d for d in diffs if d[0] == 'change')
        for d in diffs:
            if isinstance(d[2][0], (dict, list)) or isinstance(d[2][1], (dict, list)):
                if type(d[2][0]) != type(d[2][1]):
                    raise AssertionError(
                        "Check Type method: Two dictionaries have different Format: type of \"{}\" is {} in actual result while it is {} in expected result.".format(
                            d[1], type(d[2][1]), type(d[2][0])))
    except Exception as e:
        raise AssertionError("Check Type method: " + str(e))

def convert_epoch_to_date_and_time(epoch):
    """
    Convert from epoch to human-readable date with time zone in Bangkok.

    Supports Unix timestamps in seconds, milliseconds.

    The full set of format codes supported in https://strftime.org/.

    Example:

    |                                                 | Input         | Output                   |
    | Assuming That This Timestamp Is In Milliseconds | 1575339570989 | Dec 3, 2019,  2:19:30 AM |
    | Assuming That This Timestamp Is In Seconds      | 1575339570    | Dec 3, 2019,  2:19:30 AM |
    """
    try:
        if len(str(epoch)) == 13:
            seconds = int(epoch) / 1000
        else:
            seconds = epoch
        # convert it to tz
        tz = pytz.timezone('Asia/Bangkok')
        # To check the operating system
        logger.debug("Detect platform: " + platform)
        if platform == "linux" or platform == "linux2":
            exp_date = datetime.fromtimestamp(seconds).astimezone(tz).strftime('%b %-d, %Y')
        elif platform == "win32" or platform == "win64":
            exp_date = datetime.fromtimestamp(seconds).astimezone(tz).strftime('%b %#d, %Y')
        exp_time = datetime.fromtimestamp(seconds).astimezone(tz).strftime('%I:%M:%S %p')
        return exp_date, exp_time
    except Exception as e:
        raise AssertionError("Convert Epoch To Date And Time: " + str(e))

def verify_text_with_regEx(expected: str, actual: str, conj="??????") -> bool:
    """
    Verify expected text with regular expression that have conjunction is ${conj}.\n
    Return type: bool
    """
    expected = str(expected).replace("[", "\[")
    expected = str(expected).replace("]", "\]")
    expected = str(expected).replace("(", "\(")
    expected = str(expected).replace(")", "\)")
    expected = str(expected).replace(".", "\.")
    expected = str(expected).split(conj)
    size = len(expected)
    ex_reg = ''
    for i in range(size):
        if i == 0:
            ex_reg = '^' + ex_reg + expected[i] + '.*'
        elif i == size - 1:
            ex_reg = ex_reg + expected[i]
        else:
            ex_reg = ex_reg + expected[i] + '.*'
    result = re.search(ex_reg, actual)
    if result:
        return True
    else:
        return False

@keyword("Get File List As Same Type")
def get_list_testdata(path: str, filetype: str) -> list:
    all_files = [
        f for f in os.listdir(f'{path}/') if isfile(
            join(f"{path}", f)
        )
    ]
    only_files = []
    for file in all_files:
        filename = file
        file = str(file).split('.')
        if file[1] == filetype and file[0][0] != '~':
            only_files.append(filename)
    return only_files

def upload_image_without_data(url, filepath):
    files = {'media': open(filepath, 'rb')}
    response = requests.post(url, files=files, verify=False)
    return response.status_code
