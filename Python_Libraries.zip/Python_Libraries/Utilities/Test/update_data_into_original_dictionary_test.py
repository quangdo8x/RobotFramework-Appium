import unittest
from Utilities import update_data_into_original_dictionary


class Test(unittest.TestCase):
    def test1(self):
        source = {'kbankHeader': {'funcNm': 'VS3D2077O01', 'rqUID': '766_20191022_AUTOMATIONTESTING', 'rqDt': '2019-10-31T10:23:13.877+07:00', 'rqAppId': '766', 'userId': 'K0173005', 'terminalId': None, 'userLangPref': 'EN', 'corrID': None, 'authUserId': 'K0173005', 'authLevel': 1}, 'cardInfo': {'ticketId': 'f859f32ad7f447b1bf79639b4733590a', 'consent': 'Y', 'otp': '123'}}
        overrides = {'kbankHeader': {'funcNm': ''}}
        result = update_data_into_original_dictionary(source, overrides)
        assert source == {'kbankHeader': {'funcNm': 'VS3D2077O01', 'rqUID': '766_20191022_AUTOMATIONTESTING', 'rqDt': '2019-10-31T10:23:13.877+07:00', 'rqAppId': '766', 'userId': 'K0173005', 'terminalId': None, 'userLangPref': 'EN', 'corrID': None, 'authUserId': 'K0173005', 'authLevel': 1}, 'cardInfo': {'ticketId': 'f859f32ad7f447b1bf79639b4733590a', 'consent': 'Y', 'otp': '123'}}
        assert result == {'kbankHeader': {'funcNm': '', 'rqUID': '766_20191022_AUTOMATIONTESTING', 'rqDt': '2019-10-31T10:23:13.877+07:00', 'rqAppId': '766', 'userId': 'K0173005', 'terminalId': None, 'userLangPref': 'EN', 'corrID': None, 'authUserId': 'K0173005', 'authLevel': 1}, 'cardInfo': {'ticketId': 'f859f32ad7f447b1bf79639b4733590a', 'consent': 'Y', 'otp': '123'}}
        