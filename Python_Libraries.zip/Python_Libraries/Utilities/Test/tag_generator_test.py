import unittest
from tag_generator import update_dictionary_by_tags


class Tag_Generator_Test(unittest.TestCase):

    def test1(self):
        source = {'args': 'insert', 'dynamicAgentSession': 'true', 'param': {'channel': 'IB', 'custId': '[NULL]', 'ipAddress': '127.0.0.1', 'loginId': 'ibuser200', 'ssoSessionId': 'ssoSessionId'}, 'params': {'segmentId': 'IBUser'}, 'password': 'password1', 'realmId': '40151', 'userId': 'ibuser200'}
        actual = update_dictionary_by_tags(source)
        assert source['param']['custId'] == '[NULL]'
        assert actual['param']['custId'] == ''

    def test2(self):
        source = {'args': 'insert', 'dynamicAgentSession': 'true', 'param': {'channel': 'IB', 'custId': '[NULL]', 'ipAddress': '127.0.0.1', 'loginId': 'ibuser200', 'ssoSessionId': 'ssoSessionId'}, 'params': {'segmentId': '[REMOVE]'}, 'password': '[REMOVE]', 'realmId': '[REMOVE]', 'userId': '[REMOVE]'}
        actual = update_dictionary_by_tags(source)
        assert actual == {'args': 'insert', 'dynamicAgentSession': 'true', 'param': {'channel': 'IB', 'custId': '', 'ipAddress': '127.0.0.1', 'loginId': 'ibuser200', 'ssoSessionId': 'ssoSessionId'}}
