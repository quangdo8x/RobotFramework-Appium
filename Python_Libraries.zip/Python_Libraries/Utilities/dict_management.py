from dictdiffer import diff
from robot.api.deco import keyword
from operator import itemgetter
from robot.api import logger
import copy
from .utilities import *
from datetime import datetime, time, date
from decimal import Decimal


def verify_response_body(actual, expect, ignores=None, nonignores=None, check_key=True, check_datatype=True, check_value=True):
    """Verify an actual result against an expected result."""
    
    diffs = get_dict_diffs(actual, expect, ignores, nonignores, check_key, check_datatype, check_value)
    if diffs:
        raise AssertionError(print_friendly_message(diffs))
    
def get_dict_diffs(actual, expect, ignores=None, nonignores=None, check_key=True, check_datatype=True, check_value=True):
    """
    Compare the value between two dictionaries and return the change between two dictionaries.

    Argument:

    - ``actual`` the actual dictionary.

    - ``expected`` the expected dictionary.

    - ``ignores`` in case of verifying lots of keys the field list which you want to ignore.

    - ``nonignores`` in case of verifying few keys that the field list which you want to verify.

    - ``check_key`` set to False if you don't want to compare keys between two dicts.

    - ``check_datatype`` set to False if you don't want to compare datatype between two dicts.
    """
    logger.debug("This is expected result:\n")
    logger.debug(expect)        
    logger.debug("This is actual result:\n")
    logger.debug(actual)
    if check_datatype:
        check_type(actual, expect)
    diffs = list()
    if check_value:
        if ignores and isinstance(ignores, list):
            logger.debug("This is ignore list:\n")
            logger.debug(ignores)
            key_diffs = []
            if check_key:
                key_diffs = list(diff(expect, actual))
                key_diffs = list(d for d in key_diffs if (d[0] == 'add' or d[0] == 'remove'))
            value_diffs = list(diff(expect, actual, ignore=set(ignores)))
            value_diffs = list(d for d in value_diffs if d[0] == 'change')
            diffs = key_diffs + value_diffs
        elif ignores and isinstance(ignores, dict):
            raise AssertionError("Currently inputting ignores as dict is not supported")
        elif nonignores:
            logger.debug("This is the nonignore list:\n")
            logger.debug(nonignores)
            key_diffs = []
            if check_key:
                key_diffs = list(diff(expect, actual))
                key_diffs = list(d for d in key_diffs if (d[0] == 'add' or d[0] == 'remove'))
            del_expected = update_value_from_original_dictionary(expect, nonignores)
            del_actual = update_value_from_original_dictionary(actual, nonignores)
            value_diffs = list(diff(del_expected, del_actual))
            value_diffs = list(d for d in value_diffs if d[0] == 'change')
            diffs = key_diffs + value_diffs
        else:
            diffs = list(diff(expect, actual))
    logger.debug("This is the diff list:\n")
    logger.debug(diffs)
    return diffs

def update_data_into_original_dictionary(original_source, overrides):
    """
    Update data into original dictionary.
    """
    source = copy.deepcopy(original_source)
    if (overrides is not None) and (overrides != ''):
        result = recursive_update_data_into_original_dictionary(source, overrides)
    else:
        result = source
    return result

def recursive_update_data_into_original_dictionary(source, overrides):
    """
    Returns new dictionary after updating the values of ``overrides`` into ``source`` with the corresponding key.\n
    This keyword can update with multiple levels in dictionary.
    """
    for key, value in overrides.items():
        if isinstance(value, dict):
            recursive_update_data_into_original_dictionary(source.get(key, {}), value)
        elif isinstance(value, list):
            for i in range(len(value)):
                recursive_update_data_into_original_dictionary(source.get(key)[i], value[i])
        else:
            if key not in source:
                raise AssertionError(key + " does not exist.")
            else:
                source[key] = overrides[key]
    return source

def convert_suds_object_to_dict(my_suds):
    """Converts a suds object to dict."""
    logger.debug("Before converting:\n")
    logger.debug(my_suds)
    result = recursive_convert_suds_object_to_dict(my_suds)
    logger.debug("After converting:\n")
    logger.debug(result)
    return result

def recursive_convert_suds_object_to_dict(obj):
    """Converts a suds object to a dict."""
    if not hasattr(obj, '__keylist__'):
        if isinstance(obj, (datetime, time, date)):
            return obj.isoformat()
        else:
            return obj
    data = {}
    fields = obj.__keylist__
    for field in fields:
        val = getattr(obj, field)
        if isinstance(val, list):
            data[field] = []
            for item in val:
                data[field].append(recursive_convert_suds_object_to_dict(item))
        else:
            data[field] = recursive_convert_suds_object_to_dict(val)
    return data

@keyword
def update_the_value_for_the_key_list(mydic, keys, values):
    """
    Update new value for the key list from the dictionary and return the dictionary with new value.

    Argument:

    - ``mydic`` the dictionary which you want to change.

    - ``keys`` the key list which you want to update a new value.

    - ``values`` the value list which you need to update.
    """
    try:
        i = 0
        for key in keys:
            mydic = update_the_value_for_selected_key(mydic, key, values[i])
            i += 1
        return mydic
    except Exception as e:
        logger.error('Update The Value For The Key List method: ' + str(e))

@keyword
def update_the_value_for_selected_key(mydic, keyid, valueid):
    """Update the value for selected key."""
    source = copy.deepcopy(mydic)
    result = recursive_update_the_value_for_selected_key(source, keyid, valueid)
    return result
    
@keyword
def recursive_update_the_value_for_selected_key(mydic, keyid, valueid):
    """
    Update new value for selected key from the dictionary and return the dictionary with new value.

    Argument:

    - ``mydic`` the dictionary which you want to change.

    - ``keyid`` the key which you want to update a new value.

    - ``valueid`` the value which you need to update.
    """
    try:
        for key, value in mydic.items():
            if isinstance(value, dict):
                recursive_update_the_value_for_selected_key(value, keyid, valueid)
            elif isinstance(value, list):
                for i in range(len(value)):
                    recursive_update_the_value_for_selected_key(value[i], keyid, valueid)
            elif key == keyid:
                mydic[key] = valueid
        return mydic
    except Exception as e:
        logger.error('Update The Value For Selected Key method: ' + str(e))

@keyword
def get_the_value_for_selected_key(mydict, keyid):
    """
    Get the value for selected key.

    Argument:

    - ``mydict`` the dictionary which you want to change.

    - ``keyid`` the key which you want to get the value.
    """
    try:
        myvalue = None
        if isinstance(mydict, dict):
            for a_k, a_v in mydict.items():
                if isinstance(a_v, dict):
                    myvalue = get_the_value_for_selected_key(a_v, keyid)
                elif isinstance(a_v, list):
                    for i in range(len(a_v)):
                        myvalue = get_the_value_for_selected_key(a_v[i], keyid)
                else:
                    if a_k == keyid:
                        myvalue = mydict[keyid]
                        break
        # Using list comprehension
        # Get values of particular key in list of dictionaries
        elif isinstance(mydict, list):
            myvalue = map(itemgetter(keyid), mydict)
        else:
            myvalue = ""
        return myvalue
    except Exception as e:
        logger.error('Get The Value For Selected Key From The Response method: ' + str(e))

def get_keys(mydict):
    """
    Get all keys in the dictionary (*main* and *nested*).

    Argument:

    ``mydict`` the dictionary which you want to get the key.
    """
    try:
        if isinstance(mydict, dict):
            for k, v in mydict.items():
                if isinstance(v, dict):
                    yield k
                    yield from get_keys(v)
                elif isinstance(v, list):
                    for i in v:
                        yield from get_keys(i)
                else:
                    yield k
        elif isinstance(mydict, list):
            for i in mydict:
                yield from get_keys(i)
    except Exception as e:
        logger.error('Get Keys method: ' + str(e))

def get_list_diffs(list1, list2):
    """
    Custom python code to check if list one is equal to list two by taking difference.

    Argument:

    - ``list1`` the comparing list.

    - ``list2`` the standard list.
    """
    try:
        list_dif = [i for i in list1 if i not in list2]
        return list_dif
    except Exception as e:
        logger.error('Get Difference Between Two Lists method: ' + str(e))

def delete_key_in_dictionary(original_source, key):
    """Recursive delete *key* in dictionary."""
    source = copy.deepcopy(original_source)
    result = recursive_delete_key_in_dictionary(source, key)
    return result

def recursive_delete_key_in_dictionary(source, key_delete):
    """
    Returns new dictionary after removing key-value in the original dictionary.

    Argument:

    - ``source`` Original dictionary.

    - ``key_delete`` Key name need to delete.
    """
    for key, value in source.items():
        if isinstance(value, dict):
            recursive_delete_key_in_dictionary(value, key_delete)
        elif key_delete in source:
            source.pop(key_delete)
            break
    return source

def update_value_from_original_dictionary(source, source_target):
    """Recursive update the value from original dictionary."""
    try:
        target = copy.deepcopy(source_target)
        logger.debug("Source:\n")
        logger.debug(source)
        logger.debug("Target:\n")
        logger.debug(target)
        check_type(source, target)
        result = recursive_update_value_from_original_dictionary(source, target)
        logger.debug("Result:\n")
        logger.debug(result)
        return result
    except Exception as e:
        raise AssertionError("Update Value From Original Dictionary: " + str(e))

def recursive_update_value_from_original_dictionary(source, target):
    """
    Update the value from the original dictionary to the standard dictionary which has required keys.

    This method can update with multiple levels in the dictionary.
    """
    try:
        for key, value in target.items():
            if isinstance(value, dict):
                recursive_update_value_from_original_dictionary(source.get(key, {}), value)
            elif isinstance(value, list):
                for i in range(len(value)):
                    if not isinstance(value[i],str):
                        recursive_update_value_from_original_dictionary(source.get(key)[i], value[i])
                    else:
                        target[key] = source[key]
            else:
                target[key] = source[key]
        return target
    except Exception as e:
        logger.error('Recursive Update Value From Original Dictionary method: ' + str(e))

@keyword
def update_the_value_for_the_key_list_to_decimal(mydict, keys):
    """
    Update type of value from string to decimal for the key list from the dictionary and return the dictionary.

    Argument:

    - ``mydic`` the dictionary which you want to change.

    - ``keys`` the key list which you want to convert type of value from string to decimal.
    """
    try:
        for key in keys:
            print(key)
            mydict = update_the_value_for_selected_key_to_decimal(mydict, key)
        return mydict
    except Exception as e:
        logger.error('update The Value For The Key List To Decimal method: ' + str(e))

@keyword
def update_the_value_for_selected_key_to_decimal(mydic, keyid):
    """
    Update the value to decimal format for selected key. This keyword do not effect to data in mydic.
    And it return a new dictionary.

    Argument:

    - ``mydic`` the dictionary which you want to change.

    - ``keyid`` the key which you want to convert the value from string to decimal.

    """
    source = copy.deepcopy(mydic)
    result = recursive_update_the_value_for_selected_key_to_decimal(source, keyid)
    return result
    
@keyword
def recursive_update_the_value_for_selected_key_to_decimal(mydict, keyid):
    """
    Update the value to decimal format for selected key. Return the dictionary with
    type of value for the selected key from string to decimal.

    Argument:

    - ``mydict`` the dictionary which you want to change.

    - ``keyid`` the key which you want to convert the value from string to decimal.
    """
    try:
        myvalue = None
        if isinstance(mydict, dict):
            for a_k, a_v in mydict.items():
                if isinstance(a_v, dict):
                    myvalue = recursive_update_the_value_for_selected_key_to_decimal(a_v, keyid)
                elif isinstance(a_v, list):
                    for i in range(len(a_v)):
                        myvalue = recursive_update_the_value_for_selected_key_to_decimal(a_v[i], keyid)
                else:
                    if a_k == keyid:
                        myvalue = mydict[keyid]
                        mydict[keyid] = Decimal(myvalue.replace(',',''))
        return mydict
    except Exception as e:
        logger.error('Update The Value For Selected Key To Decimal method: ' + str(e))

def validate_response_body(actual, expect, ignores=None, nonignores=None, check_key=True, check_datatype=True, check_value=True):
    """Created By Thai Team

    Verify an actual result against an expected result.

    *Options*

        ``actual``: the actual dictionary.

        ``expected``: the expected dictionary.
         
        ``ignores``: in case of verifying lots of keys the field list which you want to ignore.
         
        ``nonignores``: in case of verifying few keys that the field list which you want to verify.
 
        ``check_key``: set to False if you don't want to compare keys between two dicts.
 
        ``check_datatype``: set to False if you don't want to compare datatype between two dicts.
 
        ``check_value``: set to False if you don't want to compare value between two dicts.
 
        *Examples*
 
        | `Validate_Response_Body` | actual | expect |
        | `Validate_Response_Body` | actual | expect | ignores=data.activities |
        | `Validate_Response_Body` | actual | expect | nonignores=${VALIDATE.getAccountBalances} |
        | `Validate_Response_Body` | actual | expect | check_key=False |
        | `Validate_Response_Body` | actual | expect | check_datatype=False |
        | `Validate_Response_Body` | actual | expect | check_value=False |
    """
    
    diffs = get_diffs(actual, expect, ignores, nonignores, check_key, check_datatype, check_value)
    if diffs:
        raise AssertionError(print_friendly_message(diffs))
    
def get_diffs(actual, expect, ignores=None, nonignores=None, check_key=True, check_datatype=True, check_value=True):
    """
    Compare the value between two dictionaries and return the change between two dictionaries.

    actual: the actual dictionary
    expected: the expected dictionary
    ignores: in case of verifying lots of keys the field list which you want to ignore
    nonignores: in case of verifying few keys that the field list which you want to verify
    check_key: set to False if you don't want to compare keys between two dicts
    check_datatype: set to False if you don't want to compare datatype between two dicts
    """
    logger.debug("This is expected result:\n")
    logger.debug(expect)        
    logger.debug("This is actual result:\n")
    logger.debug(actual)
    if check_datatype:
        check_type(actual, expect)
    diffs = list()
    if check_value:
        if ignores and isinstance(ignores, list):
            logger.debug("This is ignore list:\n")
            logger.debug(ignores)
            key_diffs = []
            if check_key:
                key_diffs = list(diff(expect, actual, ignore=set(ignores)))
                key_diffs = list(d for d in key_diffs if (d[0] == 'add' or d[0] == 'remove'))
            value_diffs = list(diff(expect, actual, ignore=set(ignores)))
            value_diffs = list(d for d in value_diffs if d[0] == 'change')
            diffs = key_diffs + value_diffs
        elif ignores and isinstance(ignores, dict):
            raise AssertionError("Currently inputting ignores as dict is not supported")
        elif nonignores:
            logger.debug("This is the nonignore list:\n")
            logger.debug(nonignores)
            key_diffs = []
            del_expected = update_value_from_original_dictionary(expect, nonignores)
            del_actual = update_value_from_original_dictionary(actual, nonignores)
            if check_key:
                key_diffs = list(diff(del_expected, del_actual))
                key_diffs = list(d for d in key_diffs if (d[0] == 'add' or d[0] == 'remove'))
            value_diffs = list(diff(del_expected, del_actual))
            value_diffs = list(d for d in value_diffs if d[0] == 'change')
            diffs = key_diffs + value_diffs
        else:
            diffs = list(diff(expect, actual))
    logger.debug("This is the diff list:\n")
    logger.debug(diffs)
    return diffs
