from requests import Session
from requests.auth import HTTPBasicAuth
from zeep import Transport, Client, helpers, Settings
from robot.api import logger
import urllib3
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import requests

class ZeepKeywords(object):
    
    def __init_(self):
        pass
    
    def create_soap_client(self, url_or_path, verify=False, disable_warnings=True):
        self._session = Session()
        self._session.verify = verify
        if disable_warnings:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        session = self._session
        transport = Transport(session=session)
        settings = Settings(strict=False)
        self._client = Client(url_or_path, transport=transport, settings=settings)
        return self._client
        
    def call_soap_method(self, name, *args):
        client = self._client
        method = getattr(client.service, name)
        response = method(*args)
        logger.debug(response)
        return helpers.serialize_object(response)
    
    def set_http_authentication(self, username, password):
        self._session.auth = HTTPBasicAuth(username, password)
