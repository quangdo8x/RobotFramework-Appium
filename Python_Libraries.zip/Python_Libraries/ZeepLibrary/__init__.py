from .ZeepKeywords import ZeepKeywords

class ZeepLibrary(ZeepKeywords):
    def __init__(self):
        pass
